/**
 * Created by Emlyn Hughes on 22/04/18.
 */
const i18n = new VueI18n({
	locale: 'ja', // set locale
	messages, // set locale messages
});

export default i18n;