<template>
	<div id="intro">
		<h2 class="title">{{$t("ethos.title")}}</h2>
		<p class="body_block">{{$t("ethos.body")}}</p>
	</div>
</template>

<script>
export default {
	name: "Ethos",
	data() {
		return {

		}
	},
	watch: {
	}
}
</script>

<style scoped>
	#intro {


	}
</style>