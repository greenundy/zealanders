<template>
	<div id="criteria">
		<h2 class="title">{{$t("criteria.title")}}</h2>
		<p class="body_block">{{$t("criteria.body")}}</p>
	</div>
</template>

<script>
export default {
	name: "Criteria",
	props: ['scroll'],
	data() {
		return {

		}
	},
	watch: {
	}
}
</script>

<style lang="less" scoped>
	#criteria {

	}
	h2 {

	}
</style>